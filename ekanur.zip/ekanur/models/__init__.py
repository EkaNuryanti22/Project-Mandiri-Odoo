# -*- coding: utf-8 -*-

from . import models
from . import kelompokBarang
from . import Barang
from . import Person
from . import grooming
from . import kelompokgrooming
from . import customer
from . import Supplier
from . import ResPartner
from . import Penjualan
